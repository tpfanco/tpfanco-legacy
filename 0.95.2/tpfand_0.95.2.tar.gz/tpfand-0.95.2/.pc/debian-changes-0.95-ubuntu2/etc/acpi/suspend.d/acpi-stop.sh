#!/bin/sh

# stop tpfand during suspend
/etc/init.d/tpfand stop

