#!/bin/sh

# start tpfand after resume
/etc/init.d/tpfand start

