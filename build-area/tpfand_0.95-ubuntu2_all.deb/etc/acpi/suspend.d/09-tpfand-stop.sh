#!/bin/sh

# stop tpfand during suspend
invoke-rc.d tpfand stop

