#!/bin/sh

# start tpfand after resume
invoke-rc.d tpfand start

