#!/bin/bash
#
# opens URL as user that called sudo
#

# adjust to your needs
url_opener="firefox"

if [ "$SUDO_USER" == "" ]
then
	# no sudo has happened
	$url_opener "$1" &
else
	# su back to caller account
	su -c "$url_opener \"$1\"" "${SUDO_USER}" &
fi

